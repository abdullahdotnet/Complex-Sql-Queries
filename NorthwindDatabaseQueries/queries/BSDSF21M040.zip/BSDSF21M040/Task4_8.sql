/** Task 4 Query 8 is not possible to implement because we dont have weather given explicitly and 
it is not possible to know what weather would be in each region in each month as weather dynamics 
are very different throughout the world **/
/* This query is very complex and require Data Warehouse. I tried to write this query with Ranking but wasn't able to achieve outcome*/
